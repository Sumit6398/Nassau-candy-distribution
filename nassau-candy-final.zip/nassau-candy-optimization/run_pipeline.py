"""
run_pipeline.py
---------------
Master orchestration script — runs the full Nassau Candy analytics
pipeline in the correct order from a single command.

Usage (from the project root):
    python run_pipeline.py

Stages:
    1. Data Preparation & Feature Engineering  -> outputs/processed_data.csv
    2. Predictive Modeling (LR / RF / GBR)     -> models/
    3. Route & Product Clustering              -> outputs/route_clusters.csv
    4. Scenario Simulation & Recommendations   -> outputs/recommendations.csv
    5. Static Figure Generation                -> outputs/figures/

After running this script, launch the Streamlit dashboard with:
    streamlit run app/streamlit_app.py
"""

import sys
import os
import time

# Make src/ importable
ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ROOT, "src"))

RAW_PATH = os.path.join(ROOT, "data", "Nassau_Candy_Distributor.csv")
PROCESSED_PATH = os.path.join(ROOT, "outputs", "processed_data.csv")
CLUSTERS_PATH = os.path.join(ROOT, "outputs", "route_clusters.csv")
RECS_PATH = os.path.join(ROOT, "outputs", "recommendations.csv")
MODEL_DIR = os.path.join(ROOT, "models")
FIG_DIR = os.path.join(ROOT, "outputs", "figures")


def banner(msg):
    print("\n" + "=" * 60)
    print(f"  {msg}")
    print("=" * 60)


def main():
    os.makedirs(os.path.join(ROOT, "outputs", "figures"), exist_ok=True)
    os.makedirs(MODEL_DIR, exist_ok=True)

    t0 = time.time()

    # ------------------------------------------------------------------
    # Stage 1 — Data Preparation
    # ------------------------------------------------------------------
    banner("Stage 1 / 5 — Data Preparation & Feature Engineering")
    import data_prep
    df = data_prep.run_pipeline(raw_path=RAW_PATH, out_path=PROCESSED_PATH)

    # ------------------------------------------------------------------
    # Stage 2 — Predictive Modeling
    # ------------------------------------------------------------------
    banner("Stage 2 / 5 — Predictive Modeling")
    import modeling
    run = modeling.train_all_models(df)
    modeling.save_artifacts(run, out_dir=MODEL_DIR)

    # ------------------------------------------------------------------
    # Stage 3 — Route Clustering
    # ------------------------------------------------------------------
    banner("Stage 3 / 5 — Route & Product Clustering")
    import clustering
    clustering.run(processed_path=PROCESSED_PATH, out_path=CLUSTERS_PATH)

    # ------------------------------------------------------------------
    # Stage 4 — Scenario Engine & Recommendations
    # ------------------------------------------------------------------
    banner("Stage 4 / 5 — Scenario Simulation & Recommendations")
    from scenario_engine import run as run_recs
    run_recs(out_path=RECS_PATH, priority=0.5)

    # ------------------------------------------------------------------
    # Stage 5 — Static Figures
    # ------------------------------------------------------------------
    banner("Stage 5 / 5 — Generating Static Figures")
    # Change cwd so figure script's relative paths work
    os.chdir(ROOT)
    import generate_figures
    generate_figures.fig_lead_time_dist(df)
    generate_figures.fig_lead_time_by_shipmode(df)
    generate_figures.fig_distance_vs_leadtime(df)
    generate_figures.fig_division_sales_profit(df)
    generate_figures.fig_region_volume(df)
    generate_figures.fig_model_comparison(os.path.join(MODEL_DIR, "model_metadata.json"))
    generate_figures.fig_feature_importance(
        os.path.join(MODEL_DIR, "lead_time_model.joblib"),
        os.path.join(MODEL_DIR, "model_metadata.json"),
    )
    generate_figures.fig_route_clusters(CLUSTERS_PATH)
    generate_figures.fig_recommendations(RECS_PATH)
    generate_figures.fig_factory_network()
    print(f"Figures saved to {FIG_DIR}")

    elapsed = time.time() - t0
    banner(f"Pipeline complete in {elapsed:.1f}s")
    print("  Next step:  streamlit run app/streamlit_app.py")
    print()


if __name__ == "__main__":
    main()
