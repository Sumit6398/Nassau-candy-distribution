# Deployment Guide — All 4 Submission Links

This guide gives you the exact steps to get every URL for the submission form.

---

## Link 1 — GitHub Repository Link

### Step 1: Create a GitHub account (if you don't have one)
Go to https://github.com and sign up.

### Step 2: Create a new repository
1. Click the **+** button (top right) → **New repository**
2. Name it: `nassau-candy-optimization`
3. Set to **Public**
4. Do NOT tick "Add a README" (we already have one)
5. Click **Create repository**

### Step 3: Push the project from your computer

```bash
# 1. Unzip the project (if you haven't already)
unzip nassau-candy-optimization.zip
cd nassau-candy-optimization

# 2. Initialise git
git init
git add .
git commit -m "Initial commit: Nassau Candy Factory Optimization"

# 3. Connect to your GitHub repo (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/nassau-candy-optimization.git
git branch -M main
git push -u origin main
```

Your GitHub link will be:
```
https://github.com/YOUR_USERNAME/nassau-candy-optimization
```

---

## Link 2 — Research Paper Link

The research paper PDF is already in your project at `docs/Research_Paper.pdf`.

After pushing to GitHub (Step 1 above), your research paper link is:

```
https://github.com/YOUR_USERNAME/nassau-candy-optimization/blob/main/docs/Research_Paper.pdf
```

GitHub renders PDFs directly in the browser — no extra hosting needed.

---

## Link 3 — Deployed Project Link (Streamlit)

### Step 1: Go to Streamlit Community Cloud (free)
Visit: https://share.streamlit.io

### Step 2: Sign in with GitHub
Click **Sign in with GitHub** and authorise Streamlit.

### Step 3: Deploy the app
1. Click **New app**
2. Fill in:
   - **Repository:** `YOUR_USERNAME/nassau-candy-optimization`
   - **Branch:** `main`
   - **Main file path:** `app/streamlit_app.py`
3. Click **Deploy!**

Streamlit will install dependencies and launch the app (~2–3 minutes).

Your deployed app link will be:
```
https://YOUR_USERNAME-nassau-candy-optimization-app-streamlit-app-XXXXXX.streamlit.app
```

(Streamlit shows you the exact URL after deployment.)

---

## Link 4 — Project Feedback Video Link

Record a short screen-recording video (3–5 minutes) showing:
1. Your GitHub repository and the file structure
2. The live Streamlit dashboard — show each tab
3. Brief explanation of what you built and what you learned

### Free tools to record:
- **Loom** (easiest): https://loom.com — record screen → get a sharable link instantly
- **OBS Studio** (free, desktop): https://obsproject.com → upload to YouTube → share link
- **Windows**: Press `Win + G` (Xbox Game Bar) → record screen → upload to YouTube

### Upload and share:
- **YouTube** (best): Upload → set to **Unlisted** → copy the link
- **Loom**: Click Share → copy the link
- Either gives you a valid `https://` URL

---

## Summary Checklist

| Field | URL Format |
|-------|-----------|
| GitHub Repository Link | `https://github.com/YOUR_USERNAME/nassau-candy-optimization` |
| Research Paper Link | `https://github.com/YOUR_USERNAME/nassau-candy-optimization/blob/main/docs/Research_Paper.pdf` |
| Deployed Project Link | `https://YOUR_USERNAME-nassau-...streamlit.app` |
| Feedback Video Link | `https://youtu.be/XXXXX` or `https://loom.com/share/XXXXX` |

---

## Troubleshooting

**"git push" asks for a password?**  
Use a Personal Access Token instead of your password:  
GitHub → Settings → Developer settings → Personal access tokens → Generate new token (classic) → tick `repo` → Copy the token → use it as the password.

**Streamlit Cloud shows an error?**  
- Check that `data/Nassau_Candy_Distributor.csv` was pushed to GitHub
- Check that `requirements.txt` is at the root of the repo
- The main file path must be exactly `app/streamlit_app.py`

**PDF link shows "raw" download instead of preview?**  
Change `/blob/` to `/blob/` in the URL — GitHub should auto-preview PDFs.  
If not, you can also upload the PDF to Google Drive and share that link instead.
