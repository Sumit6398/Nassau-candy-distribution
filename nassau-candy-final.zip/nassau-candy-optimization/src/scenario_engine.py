"""
scenario_engine.py
-------------------
Scenario Simulation Engine + Optimization & Recommendation Logic.

For each product, simulates reassigning it from its current factory to
every alternate factory, using the trained lead-time model and the same
logistics-cost formula from data_prep, then ranks candidate factories by
a configurable speed-vs-profit priority and produces top-N
recommendations.

This module is imported directly by the Streamlit app so the dashboard
and the batch script share identical logic.
"""

import joblib
import json
import numpy as np
import pandas as pd

from geocoding import distance_factory_to_state, FACTORY_COORDINATES
from data_prep import (
    PRODUCT_FACTORY_MAP,
    SHIP_MODE_PARAMS,
    LOGISTICS_RATE_PER_MILE_PER_UNIT,
)

ALL_FACTORIES = list(FACTORY_COORDINATES.keys())


class RecommendationEngine:
    def __init__(
        self,
        processed_data_path="outputs/processed_data.csv",
        model_path="models/lead_time_model.joblib",
        metadata_path="models/model_metadata.json",
    ):
        self.df = pd.read_csv(processed_data_path)
        self.model = joblib.load(model_path)
        with open(metadata_path) as f:
            self.meta = json.load(f)
        self.feature_cols = self.meta["feature_cols"]
        self.model_r2 = self.meta["metrics"][self.meta["best_model"]]["R2"]

    # ------------------------------------------------------------------
    # Feature construction for simulated (counterfactual) scenarios
    # ------------------------------------------------------------------
    def _build_features(self, subset, factory_override):
        """Recompute Distance Miles for `factory_override` and one-hot
        encode the subset to match the model's training feature schema."""
        sim = subset.copy()
        sim["Distance Miles"] = sim["State/Province"].apply(
            lambda sp: distance_factory_to_state(factory_override, sp)
        )
        sim["Current Factory"] = factory_override

        cat_cols = ["Ship Mode", "Region", "Division", "Current Factory"]
        encoded = pd.get_dummies(sim, columns=cat_cols, prefix=cat_cols)
        # Align to training schema: add any missing dummy cols as 0,
        # drop extras, preserve column order.
        for col in self.feature_cols:
            if col not in encoded.columns:
                encoded[col] = 0
        X = encoded[self.feature_cols]
        return sim, X

    def _predict_lead_time(self, subset, factory_override):
        sim, X = self._build_features(subset, factory_override)
        sim["Predicted Lead Time"] = self.model.predict(X)
        return sim

    def _apply_cost_model(self, sim):
        rate = sim["Ship Mode"].map(LOGISTICS_RATE_PER_MILE_PER_UNIT)
        sim["Sim Logistics Cost"] = sim["Distance Miles"] * rate * sim["Units"]
        sim["Sim Adjusted Profit"] = sim["Gross Profit"] - sim["Sim Logistics Cost"]
        return sim

    # ------------------------------------------------------------------
    # Single product x factory scenario
    # ------------------------------------------------------------------
    def simulate(self, product, factory_override):
        subset = self.df[self.df["Product Name"] == product]
        if subset.empty:
            raise ValueError(f"No historical orders for product: {product}")
        sim = self._predict_lead_time(subset, factory_override)
        sim = self._apply_cost_model(sim)
        return {
            "Product Name": product,
            "Factory": factory_override,
            "Avg Predicted Lead Time": round(sim["Predicted Lead Time"].mean(), 2),
            "Avg Distance Miles": round(sim["Distance Miles"].mean(), 1),
            "Total Adjusted Profit": round(sim["Sim Adjusted Profit"].sum(), 2),
            "Avg Profit Margin %": round(
                (sim["Sim Adjusted Profit"].sum() / sim["Sales"].sum()) * 100, 2
            ),
            "Order Volume": len(sim),
        }

    # ------------------------------------------------------------------
    # All factories for one product, with current factory flagged
    # ------------------------------------------------------------------
    def compare_all_factories(self, product):
        current_factory = PRODUCT_FACTORY_MAP[product]
        rows = [self.simulate(product, f) for f in ALL_FACTORIES]
        out = pd.DataFrame(rows)
        out["Is Current"] = out["Factory"] == current_factory

        current_row = out[out["Is Current"]].iloc[0]
        total_sales = self.df.loc[self.df["Product Name"] == product, "Sales"].sum()

        out["Lead Time Change %"] = (
            (current_row["Avg Predicted Lead Time"] - out["Avg Predicted Lead Time"])
            / current_row["Avg Predicted Lead Time"] * 100
        ).round(2)
        out["Profit Change ($)"] = (
            out["Total Adjusted Profit"] - current_row["Total Adjusted Profit"]
        ).round(2)
        # Expressed as a % of total product sales (a stable denominator) --
        # NOT % of current profit, since current profit can be near zero
        # for low-volume products and would blow up the percentage.
        out["Profit Change %"] = (out["Profit Change ($)"] / total_sales * 100).round(2)
        return out.sort_values("Avg Predicted Lead Time").reset_index(drop=True)

    # ------------------------------------------------------------------
    # Ranking / recommendation with speed-vs-profit priority slider
    # ------------------------------------------------------------------
    def recommend(self, product, priority=0.5, top_n=3):
        """priority: 0.0 = optimize purely for profit, 1.0 = optimize
        purely for speed (lead time reduction). 0.5 = balanced.

        Includes the current factory as a baseline candidate (with
        Lead Time Change % = 0, Profit Change % = 0) so that "keep the
        current assignment" is a real possible outcome, not guaranteed
        to lose to every alternative by construction."""
        comparison = self.compare_all_factories(product)
        candidates = comparison.copy()
        if candidates.empty:
            return comparison, pd.DataFrame()

        # Normalize each metric 0-1 across ALL factories (including current)
        lt_norm = self._normalize(candidates["Lead Time Change %"])
        profit_norm = self._normalize(candidates["Profit Change %"])
        candidates["Score"] = (priority * lt_norm + (1 - priority) * profit_norm).round(4)

        candidates["Confidence Score"] = candidates["Order Volume"].apply(
            lambda v: round(min(1.0, v / 100) * self.model_r2, 3)
        )
        candidates["Risk Flag"] = np.where(
            candidates["Is Current"], "N/A (Current)",
            np.where(
                candidates["Profit Change %"] < -2, "High Risk",
                np.where(candidates["Profit Change %"] < 0, "Caution", "Low Risk"),
            ),
        )

        ranked_all = candidates.sort_values("Score", ascending=False).reset_index(drop=True)
        # Recommendations shown to the user exclude the current factory
        # (no point "recommending" the status quo), but the ranking that
        # decides Keep-vs-Reassign considers it.
        ranked_alternatives = ranked_all[~ranked_all["Is Current"]].head(top_n).reset_index(drop=True)
        return comparison, ranked_alternatives, ranked_all

    @staticmethod
    def _normalize(series):
        lo, hi = series.min(), series.max()
        if hi - lo < 1e-9:
            return pd.Series(0.5, index=series.index)
        return (series - lo) / (hi - lo)

    # ------------------------------------------------------------------
    # Batch: top recommendation for every product (Recommendation Dashboard)
    # ------------------------------------------------------------------
    def recommend_all_products(self, priority=0.5):
        records = []
        for product in PRODUCT_FACTORY_MAP:
            _, ranked_alternatives, ranked_all = self.recommend(product, priority=priority, top_n=1)
            current_factory = PRODUCT_FACTORY_MAP[product]
            if ranked_alternatives.empty:
                continue
            top_overall = ranked_all.iloc[0]
            best_alt = ranked_alternatives.iloc[0]
            keep_current = bool(top_overall["Is Current"])
            records.append({
                "Product Name": product,
                "Current Factory": current_factory,
                "Recommended Factory": current_factory if keep_current else best_alt["Factory"],
                "Lead Time Change %": 0.0 if keep_current else best_alt["Lead Time Change %"],
                "Profit Change %": 0.0 if keep_current else best_alt["Profit Change %"],
                "Confidence Score": best_alt["Confidence Score"],
                "Risk Flag": "N/A (Current)" if keep_current else best_alt["Risk Flag"],
                "Action": "Keep Current" if keep_current else "Reassign",
            })
        return pd.DataFrame(records)


def run(out_path="outputs/recommendations.csv", priority=0.5):
    engine = RecommendationEngine()
    recs = engine.recommend_all_products(priority=priority)
    recs.to_csv(out_path, index=False)
    print(f"Generated recommendations for {len(recs)} products -> {out_path}")
    print(recs.to_string(index=False))
    coverage = (recs["Action"] == "Reassign").mean() * 100
    print(f"\nRecommendation Coverage (products with a beneficial reassignment): {coverage:.1f}%")
    return recs


if __name__ == "__main__":
    run()
