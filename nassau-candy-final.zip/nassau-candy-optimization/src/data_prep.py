"""
data_prep.py
------------
End-to-end data preparation for the Nassau Candy Factory Reallocation &
Shipping Optimization project.

What this script does:
1. Loads the raw transaction-level CSV.
2. Joins each order to its CURRENT factory assignment via the
   Division/Product -> Factory correlation table supplied in the project
   brief.
3. Computes the great-circle distance (miles) between the assigned
   factory and the customer's state/province centroid.
4. Engineers a REALISTIC Lead Time target, since the raw Order Date /
   Ship Date columns are synthetic noise with no real relationship to
   ship mode or distance (verified during EDA: Same Day shipments
   averaged ~1333 days vs ~1314 for Standard Class, a contradiction).
   The engineered lead time follows a standard "service-level + distance"
   shipping model:
        lead_time_days = base_days[ship_mode]
                        + distance_miles / speed_mph[ship_mode]
                        + noise
   This keeps the field learnable (so the modeling stage is meaningful)
   while remaining directionally honest: faster service levels and
   shorter distances produce shorter lead times.
5. Engineers an estimated logistics cost per order (a function of
   distance, units, and ship mode), and derives an Adjusted Gross Profit
   that reflects logistics drag -- this is what lets the scenario engine
   quantify "margin erosion due to logistics inefficiencies."
6. Encodes categorical variables and writes a clean, model-ready dataset
   to outputs/processed_data.csv.

All engineered-value assumptions are documented inline and in the
research paper.
"""

import numpy as np
import pandas as pd
from geocoding import distance_factory_to_state, factory_coords, FACTORY_COORDINATES

RANDOM_SEED = 42

# Current static Division/Product -> Factory assignment, as supplied in
# the project brief ("Products and Factories Correlation" table).
PRODUCT_FACTORY_MAP = {
    "Wonka Bar - Nutty Crunch Surprise": "Lot's O' Nuts",
    "Wonka Bar - Fudge Mallows": "Lot's O' Nuts",
    "Wonka Bar -Scrumdiddlyumptious": "Lot's O' Nuts",
    "Wonka Bar - Milk Chocolate": "Wicked Choccy's",
    "Wonka Bar - Triple Dazzle Caramel": "Wicked Choccy's",
    "Laffy Taffy": "Sugar Shack",
    "SweeTARTS": "Sugar Shack",
    "Nerds": "Sugar Shack",
    "Fun Dip": "Sugar Shack",
    "Fizzy Lifting Drinks": "Sugar Shack",
    "Everlasting Gobstopper": "Secret Factory",
    "Hair Toffee": "The Other Factory",
    "Lickable Wallpaper": "Secret Factory",
    "Wonka Gum": "Secret Factory",
    "Kazookles": "The Other Factory",
}

ALL_FACTORIES = list(FACTORY_COORDINATES.keys())

# Shipping service-level assumptions used to engineer a realistic lead
# time from distance. Units: base_days is a fixed handling/dispatch
# delay; speed_mph is an effective network transit speed (covers ground
# / air network averages, not literal vehicle speed).
SHIP_MODE_PARAMS = {
    "Same Day":       {"base_days": 0.2, "speed_mph": 1500},
    "First Class":    {"base_days": 1.0, "speed_mph": 1000},
    "Second Class":   {"base_days": 1.5, "speed_mph": 600},
    "Standard Class": {"base_days": 2.0, "speed_mph": 400},
}

# Estimated logistics cost in $ per mile per unit shipped, by ship mode.
# Faster service levels cost more per mile -- this is what creates
# "margin erosion" when a product is reassigned to a more distant factory.
# Calibrated so average logistics cost lands at roughly 30-45% of average
# gross profit (~$9.17/order) for typical orders, with long-haul /
# high-unit / expedited orders showing the real margin erosion the
# project brief is concerned with -- rather than swamping every order.
LOGISTICS_RATE_PER_MILE_PER_UNIT = {
    "Same Day": 0.0030,
    "First Class": 0.0015,
    "Second Class": 0.0009,
    "Standard Class": 0.0005,
}


def load_raw(path):
    df = pd.read_csv(path)
    df["Order Date"] = pd.to_datetime(df["Order Date"], format="%d-%m-%Y")
    df["Ship Date"] = pd.to_datetime(df["Ship Date"], format="%d-%m-%Y")
    return df


def engineer_features(df, seed=RANDOM_SEED):
    rng = np.random.default_rng(seed)
    df = df.copy()

    # 1. Current factory assignment per product
    df["Current Factory"] = df["Product Name"].map(PRODUCT_FACTORY_MAP)
    unmapped = df["Current Factory"].isna().sum()
    if unmapped:
        raise ValueError(f"{unmapped} rows have a product with no factory mapping")

    # 2. Distance from current factory to customer (state/province centroid)
    df["Distance Miles"] = df.apply(
        lambda r: distance_factory_to_state(r["Current Factory"], r["State/Province"]),
        axis=1,
    )

    # 3. Engineered realistic lead time
    base = df["Ship Mode"].map(lambda m: SHIP_MODE_PARAMS[m]["base_days"])
    speed = df["Ship Mode"].map(lambda m: SHIP_MODE_PARAMS[m]["speed_mph"])
    noise = rng.normal(0, 0.4, size=len(df))
    df["Lead Time Days"] = (base + df["Distance Miles"] / speed + noise).clip(lower=0.5).round(2)

    # 4. Estimated logistics cost & adjusted gross profit
    rate = df["Ship Mode"].map(LOGISTICS_RATE_PER_MILE_PER_UNIT)
    df["Logistics Cost"] = (df["Distance Miles"] * rate * df["Units"]).round(2)
    df["Adjusted Gross Profit"] = (df["Gross Profit"] - df["Logistics Cost"]).round(2)
    df["Profit Margin %"] = (df["Adjusted Gross Profit"] / df["Sales"] * 100).round(2)

    return df


def build_categorical_encodings(df):
    """One-hot encode the categorical predictors used for modeling.
    Returns (encoded_df, list_of_feature_columns)."""
    cat_cols = ["Ship Mode", "Region", "Division", "Current Factory"]
    encoded = pd.get_dummies(df, columns=cat_cols, prefix=cat_cols)
    feature_cols = ["Distance Miles", "Units"] + [
        c for c in encoded.columns
        if any(c.startswith(p + "_") for p in cat_cols)
    ]
    return encoded, feature_cols


def run_pipeline(raw_path, out_path):
    df = load_raw(raw_path)
    df = engineer_features(df)
    df.to_csv(out_path, index=False)
    print(f"Processed {len(df)} rows -> {out_path}")
    print(df[["Distance Miles", "Lead Time Days", "Logistics Cost", "Adjusted Gross Profit"]].describe())
    return df


if __name__ == "__main__":
    run_pipeline(
        raw_path="data/Nassau_Candy_Distributor.csv",
        out_path="outputs/processed_data.csv",
    )
