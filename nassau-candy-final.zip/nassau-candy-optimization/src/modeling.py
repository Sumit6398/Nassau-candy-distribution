"""
modeling.py
-----------
Predictive Modeling stage: predict expected shipping Lead Time (days)
given Product (-> Division/Current Factory), origin factory, destination
region, and ship mode.

Trains three models per the project brief:
    - Linear Regression (baseline)
    - Random Forest Regressor
    - Gradient Boosting Regressor

Evaluates each with RMSE, MAE, R^2, picks the best performer balancing
accuracy + interpretability, and persists it (with the feature schema)
for use by the scenario simulation engine and the Streamlit app.
"""

import json
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

from data_prep import build_categorical_encodings

RANDOM_SEED = 42
TARGET = "Lead Time Days"


def load_processed(path="outputs/processed_data.csv"):
    return pd.read_csv(path)


def make_train_test(df):
    encoded, feature_cols = build_categorical_encodings(df)
    X = encoded[feature_cols]
    y = encoded[TARGET]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=RANDOM_SEED
    )
    return X_train, X_test, y_train, y_test, feature_cols


def evaluate(model, X_test, y_test):
    preds = model.predict(X_test)
    rmse = float(np.sqrt(mean_squared_error(y_test, preds)))
    mae = float(mean_absolute_error(y_test, preds))
    r2 = float(r2_score(y_test, preds))
    return {"RMSE": round(rmse, 4), "MAE": round(mae, 4), "R2": round(r2, 4)}


def train_all_models(df):
    X_train, X_test, y_train, y_test, feature_cols = make_train_test(df)

    models = {
        "Linear Regression": LinearRegression(),
        "Random Forest": RandomForestRegressor(
            n_estimators=300, max_depth=12, random_state=RANDOM_SEED, n_jobs=-1
        ),
        "Gradient Boosting": GradientBoostingRegressor(
            n_estimators=300, max_depth=3, learning_rate=0.05, random_state=RANDOM_SEED
        ),
    }

    results = {}
    fitted = {}
    for name, model in models.items():
        model.fit(X_train, y_train)
        metrics = evaluate(model, X_test, y_test)
        results[name] = metrics
        fitted[name] = model
        print(f"{name:20s} RMSE={metrics['RMSE']:.3f}  MAE={metrics['MAE']:.3f}  R2={metrics['R2']:.3f}")

    # Best model: highest R2 (primary), tie-broken by lowest RMSE
    best_name = max(results, key=lambda n: (results[n]["R2"], -results[n]["RMSE"]))
    best_model = fitted[best_name]
    print(f"\nBest model selected: {best_name}")

    return {
        "results": results,
        "best_name": best_name,
        "best_model": best_model,
        "feature_cols": feature_cols,
        "X_test": X_test,
        "y_test": y_test,
    }


def save_artifacts(run, out_dir="models"):
    joblib.dump(run["best_model"], f"{out_dir}/lead_time_model.joblib")
    meta = {
        "best_model": run["best_name"],
        "feature_cols": run["feature_cols"],
        "metrics": run["results"],
    }
    with open(f"{out_dir}/model_metadata.json", "w") as f:
        json.dump(meta, f, indent=2)
    print(f"Saved model -> {out_dir}/lead_time_model.joblib")
    print(f"Saved metadata -> {out_dir}/model_metadata.json")


if __name__ == "__main__":
    df = load_processed()
    run = train_all_models(df)
    save_artifacts(run)
